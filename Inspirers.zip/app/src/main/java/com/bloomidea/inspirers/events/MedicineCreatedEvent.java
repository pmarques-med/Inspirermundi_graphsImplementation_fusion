package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 31/03/17.
 */

public class MedicineCreatedEvent {
}
