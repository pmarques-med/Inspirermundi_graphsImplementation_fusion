package com.bloomidea.inspirers.listener;

/**
 * Created by michellobato on 29/09/14.
 */
public interface PictureLoadListener {
    void onEndLoad(boolean ok);
}
