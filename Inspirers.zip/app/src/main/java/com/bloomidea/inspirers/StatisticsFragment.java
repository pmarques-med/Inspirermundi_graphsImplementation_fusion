package com.bloomidea.inspirers;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bloomidea.inspirers.application.AppController;
import com.bloomidea.inspirers.customViews.MyRegFragment;
import com.bloomidea.inspirers.events.UserStatsModifiedEvent;
import com.bloomidea.inspirers.model.User;
import com.github.lzyzsd.circleprogress.DonutProgress;

import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


public class StatisticsFragment extends MyRegFragment {
    private View rootView;

    private Subscriber<? super Object> interfaceEvents = new Subscriber<Object>() {
        @Override
        public void onCompleted() {
        }

        @Override
        public void onError(Throwable e) {
        }

        @Override
        public void onNext(Object o) {
            if (o instanceof UserStatsModifiedEvent) {
                loadValues();
            }
        }
    };

    public StatisticsFragment() {
    }

    public static StatisticsFragment newInstance() {
        StatisticsFragment fragment = new StatisticsFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_statistics, container, false);


        View aux = rootView.findViewById(R.id.linearLayout_stats);
        aux.setPadding(aux.getPaddingLeft(),aux.getPaddingTop(),aux.getPaddingRight(),getResources().getDimensionPixelOffset(R.dimen.bottom_stats_padding));

        loadValues();

        return rootView;
    }

    private void loadValues() {
        if(rootView!=null) {
            User aux = AppController.getmInstance().getActiveUser();

            GregorianCalendar firstMedDate = AppController.getmInstance().getTimelineDataSource().getFirstMedicineDate(aux.getId());
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            if (firstMedDate != null) {
                ((TextView) rootView.findViewById(R.id.init_date_textView)).setText(getResources().getString(R.string.stats_started_in, dateFormat.format(firstMedDate.getTime())));
            } else {
                rootView.findViewById(R.id.init_date_textView).setVisibility(View.GONE);
            }

            ((DonutProgress) rootView.findViewById(R.id.stats_begining_donut_progress)).setUnfinishedStrokeColor(Color.parseColor(aux.getStatsEverColor()));
            ((DonutProgress) rootView.findViewById(R.id.stats_begining_donut_progress)).setProgress(100 - aux.getStatsEver().intValue());
            ((TextView) rootView.findViewById(R.id.percent_beginning_textview)).setText(aux.getStatsEver().setScale(0, RoundingMode.HALF_UP).toPlainString());

            ((DonutProgress) rootView.findViewById(R.id.stats_month_donut_progress)).setUnfinishedStrokeColor(Color.parseColor(aux.getStatsMonthColor()));
            ((DonutProgress) rootView.findViewById(R.id.stats_month_donut_progress)).setProgress(100 - aux.getStatsMonth().intValue());
            ((TextView) rootView.findViewById(R.id.percent_month_textview)).setText(aux.getStatsMonth().setScale(0, RoundingMode.HALF_UP).toPlainString());

            ((DonutProgress) rootView.findViewById(R.id.stats_7_days_donut_progress)).setUnfinishedStrokeColor(Color.parseColor(aux.getStatsWeekColor()));
            ((DonutProgress) rootView.findViewById(R.id.stats_7_days_donut_progress)).setProgress(100 - aux.getStatsWeek().intValue());
            ((TextView) rootView.findViewById(R.id.percent_7_days_textview)).setText(aux.getStatsWeek().setScale(0, RoundingMode.HALF_UP).toPlainString());
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        AppController.getmInstance().getMyBus().toObserverable()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(interfaceEvents);
    }

    @Override
    public void onDetach() {
        super.onDetach();

        interfaceEvents.unsubscribe();
    }
}
