package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 27/04/17.
 */

public class PollAnswered {
    private long poolId;

    public PollAnswered(long poolId) {
        this.poolId = poolId;
    }
}
