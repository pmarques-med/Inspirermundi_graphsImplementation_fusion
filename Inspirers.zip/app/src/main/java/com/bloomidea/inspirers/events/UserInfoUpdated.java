package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 20/04/17.
 */

public class UserInfoUpdated {
}
