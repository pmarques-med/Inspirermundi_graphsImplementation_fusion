package com.bloomidea.inspirers;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.SwitchCompat;
import android.text.Html;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bloomidea.inspirers.application.AppController;
import com.bloomidea.inspirers.customViews.MyActiveActivity;
import com.bloomidea.inspirers.model.TimelineItem;
import com.bloomidea.inspirers.model.UserNormalMedicine;
import com.bloomidea.inspirers.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class InviteDoctorActivity extends MyActiveActivity {
    private static final int MY_PERMISSIONS_REQUEST_READ_WRITE = 300;

    private boolean shareAll = true;
    private View dates_box;
    private View start_date_box;
    private View end_date_box;
    private GregorianCalendar startDate = null;
    private GregorianCalendar endDate = null;
    private TextView startDateTextView;
    private TextView endDateTextView;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private SimpleDateFormat dateFormatter = new SimpleDateFormat("EEE, d MMM yyyy");
    private SimpleDateFormat dateFormatterTime = new SimpleDateFormat("HH:mm");
    private SimpleDateFormat dateFormatterFiles = new SimpleDateFormat("dd/MM/yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_doctor);

        findViewById(R.id.back_btn_imageView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ((ImageView) findViewById(R.id.icon_imageView)).setImageResource(R.drawable.share_with_doctor_icon_green);
        ((TextView) findViewById(R.id.title_textView)).setText(R.string.share_with_doctor_btn);

        ((TextView) findViewById(R.id.share_doctor_text)).setText(Html.fromHtml(getString(R.string.share_with_doctor_desc)));

        dates_box = findViewById(R.id.dates_box);
        start_date_box = findViewById(R.id.start_date_box);
        end_date_box = findViewById(R.id.end_date_box);
        startDateTextView = (TextView) findViewById(R.id.start_date_textView);
        endDateTextView = (TextView) findViewById(R.id.end_date_textView);

        ((SwitchCompat) findViewById(R.id.share_all_switch)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                shareAll = b;
                configureDates();
            }
        });

        start_date_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GregorianCalendar dateAux = startDate;
                if(dateAux == null)
                    dateAux = new GregorianCalendar();

                DatePickerDialog datePickerDialog = new DatePickerDialog(InviteDoctorActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        startDate = new GregorianCalendar(year,monthOfYear,dayOfMonth);
                        startDate.set(Calendar.HOUR_OF_DAY,0);
                        startDate.set(Calendar.MINUTE,0);
                        startDate.set(Calendar.SECOND,0);
                        startDate.set(Calendar.MILLISECOND,0);

                        setDateText(startDateTextView,startDate);
                    }
                }, dateAux.get(Calendar.YEAR), dateAux.get(Calendar.MONTH), dateAux.get(Calendar.DAY_OF_MONTH));

                datePickerDialog.show();
            }
        });

        end_date_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GregorianCalendar dateAux = endDate;
                if(dateAux == null)
                    dateAux = new GregorianCalendar();

                DatePickerDialog datePickerDialog = new DatePickerDialog(InviteDoctorActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        endDate = new GregorianCalendar(year,monthOfYear,dayOfMonth);
                        endDate.set(Calendar.HOUR_OF_DAY,23);
                        endDate.set(Calendar.MINUTE,59);
                        endDate.set(Calendar.SECOND,59);
                        endDate.set(Calendar.MILLISECOND,0);

                        setDateText(endDateTextView,endDate);
                    }
                }, dateAux.get(Calendar.YEAR), dateAux.get(Calendar.MONTH), dateAux.get(Calendar.DAY_OF_MONTH));

                datePickerDialog.show();
            }
        });

        String userName = AppController.getmInstance().getActiveUser().getUserName();
        ((EditText)findViewById(R.id.send_invite_text_editText)).setText(getResources().getString(R.string.doctor_email_text_hint, userName, userName));

        configureDates();

        findViewById(R.id.send_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = ((EditText) findViewById(R.id.doctor_email)).getText().toString();

                if(checkData(email)){
                    ArrayList<TimelineItem> medicineList;
                    String filename;
                    if(shareAll) {
                        medicineList = AppController.getmInstance().getTimelineDataSource().getAllUserNormalMedicinesShareDoctor(AppController.getmInstance().getActiveUser().getId());
                        filename = getString(R.string.csv_all_file_name);
                    }else{
                        medicineList = AppController.getmInstance().getTimelineDataSource().getAllUserNormalMedicinesShareDoctor(AppController.getmInstance().getActiveUser().getId(),startDate,endDate);
                        filename= getString(R.string.csv_time_interval_file_name);
                    }

                    if(medicineList == null || medicineList.isEmpty()){
                        Toast.makeText(InviteDoctorActivity.this,R.string.noting_to_share,Toast.LENGTH_SHORT).show();
                    }else{
                        if(checkPermissions()) {
                            Utils.createNavigationAction(getString(R.string.send_report_doctor));

                            EditText editText = ((EditText) findViewById(R.id.send_invite_text_editText));


                            String csv = convertToCsvString(medicineList);
                            Uri csvFile = saveCSVToFile(csv,filename);

                            Intent sendIntent = new Intent(Intent.ACTION_SEND);
                            sendIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.share_with_doctor_email_subject));
                            sendIntent.putExtra(Intent.EXTRA_STREAM, csvFile);
                            sendIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                            sendIntent.putExtra(Intent.EXTRA_TEXT, editText.getText().toString().isEmpty() ? editText.getHint().toString() : editText.getText().toString());
                            sendIntent.setType("text/html");
                            startActivity(sendIntent);
                        }
                    }
                }
            }
        });
    }

    private boolean checkPermissions(){
        boolean permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

        if(!permissionCheck) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_WRITE);
        }

        return permissionCheck;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_READ_WRITE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                findViewById(R.id.send_btn).performClick();
            }
        }else{
            super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
    }

    private Uri saveCSVToFile(String csv, String fileName){
        File file   = null;
        File root   = Environment.getExternalStorageDirectory();
        if (root.canWrite()){
            File dir    =   new File (root.getAbsolutePath() + "/PersonData");
            dir.mkdirs();
            file   =   new File(dir, fileName+".csv");
            FileOutputStream out   =   null;
            try {
                out = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                out.write(csv.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Uri u1  = null;

        if(file!=null) {
            u1 = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", file);//Uri.fromFile(file);
        }

        return u1;
    }

    private String convertToCsvString(ArrayList<TimelineItem> mediciItems){
        String result = getString(R.string.csv_file_header)+"\n";

        for(TimelineItem item : mediciItems){
            if(item.getDateTaken() != null){
                result += "\""+dateFormatter.format(item.getDateTaken().getTime()) + "\",";
                result += dateFormatterTime.format(item.getDateTaken().getTime()) + ",";
            }else{
                result += "---"+",";
                result += "---"+",";
            }

            result += (item.getMedicine().getMedicineName()) + ",";
            result += (item.getDosage()) + ",";
            result += (item.getMedicine().getMedicineType().getName()) + ",";
            result += ((item.isSOS()) ? getResources().getString(R.string.yes) : getResources().getString(R.string.no)) + ",";
            result += ((item.getState() != null && item.getState().equals(TimelineItem.STATE_LATE)) ? getResources().getString(R.string.yes) : getResources().getString(R.string.no)) + ",";
            result += (item.getFaseTime()==null?"---":item.getFaseTime().getDesc()) + ",";

            int duration = (item.getMedicine() instanceof UserNormalMedicine ? ((UserNormalMedicine) item.getMedicine()).getDuration() : 1);

            result += getResources().getQuantityString(R.plurals.duration_days, duration, duration) + ",";
            result += dateFormatterFiles.format(item.getMedicine().getStartDate().getTime());

            result += "\n";

        }

        return result;
    }

    private boolean checkData(String email) {
        boolean ok = false;

        if(email == null || email.isEmpty()){
            Toast.makeText(this,R.string.doctor_email_empty_error,Toast.LENGTH_SHORT).show();
        }else if(!Utils.isEmailValid(email)){
            Toast.makeText(this,R.string.doctor_email_invalid,Toast.LENGTH_SHORT).show();
        }else if(!shareAll && (startDate == null || endDate == null)){
            Toast.makeText(this,R.string.doctor_dates_empty_error,Toast.LENGTH_SHORT).show();
        }else{
            ok = true;
        }

        return ok;
    }

    private void setDateText(TextView textView, GregorianCalendar dateAux){
        if(dateAux!=null) {
            textView.setText(dateFormat.format(dateAux.getTime()));
        }else {
            textView.setText(R.string.date_init_text);
        }
    }

    private void configureDates() {
        if(shareAll){
            dates_box.setAlpha(0.3f);
            startDate = null;
            endDate = null;

            setDateText(startDateTextView,null);
            setDateText(endDateTextView,null);

            start_date_box.setClickable(false);
            end_date_box.setClickable(false);
        }else{
            dates_box.setAlpha(1);

            start_date_box.setClickable(true);
            end_date_box.setClickable(true);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
}
