package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 07/04/17.
 */

public class UserBadgeWon {
}
