package com.bloomidea.inspirers.utils;

import android.content.Context;

import com.bloomidea.inspirers.R;
import com.bloomidea.inspirers.model.MedicineType;

import org.medida.inhalerdetection.InhalerDetectionActivity;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by michellobato on 22/03/17.
 */

public class MedicineTypeAux {
    private static String[] medicinesNeedInlNames;

    private static HashMap<String,InhalerDetectionActivity.InhalerType> listMedicineNameRecognitionCodeToTake;

    //public static final String TYPE1_CODE = "INAL";
    //private static final String TYPE2_CODE = "PILS";
    //private static final String TYPE3_CODE = "INAL_NAR";

    public static final String TYPE1_CODE = "med_type_inhalation";
    private static final String TYPE2_CODE = "med_type_pill";
    private static final String TYPE3_CODE = "med_type_nostil";

    private static ArrayList<MedicineType> listMediceTypes;

    public static HashMap<String,InhalerDetectionActivity.InhalerType> getListMedicineNameRecognitionCodeToTake(){
        if(listMedicineNameRecognitionCodeToTake == null){
            listMedicineNameRecognitionCodeToTake = new HashMap<>();

            //Diskus
            listMedicineNameRecognitionCodeToTake.put("Asmatil Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Asmo-Lavi Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Brisomax Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Brisovent Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Dilamax Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Flixotaide Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Maizar Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Seretaide Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Serevent Diskus",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Veraspir Diskus",InhalerDetectionActivity.InhalerType.Diskus);

            listMedicineNameRecognitionCodeToTake.put("Beglán-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Betamican-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Inaspir-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Serevent-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Anasma-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Inaladúo-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("PlusVent-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Seretide-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Flixotide-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Flusonal-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Inalacor-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);
            listMedicineNameRecognitionCodeToTake.put("Trialona-Accuhaler",InhalerDetectionActivity.InhalerType.Diskus);

            //Ellipta
            listMedicineNameRecognitionCodeToTake.put("Relvar Ellipta",InhalerDetectionActivity.InhalerType.Ellipta);
            listMedicineNameRecognitionCodeToTake.put("Anoro",InhalerDetectionActivity.InhalerType.Ellipta);
            listMedicineNameRecognitionCodeToTake.put("Incruse",InhalerDetectionActivity.InhalerType.Ellipta);
            listMedicineNameRecognitionCodeToTake.put("Laventair",InhalerDetectionActivity.InhalerType.Ellipta);
            listMedicineNameRecognitionCodeToTake.put("Revinty",InhalerDetectionActivity.InhalerType.Ellipta);

            //Flutiform
            listMedicineNameRecognitionCodeToTake.put("Flutiform",InhalerDetectionActivity.InhalerType.Flutiform);

            //Novolizer
            listMedicineNameRecognitionCodeToTake.put("Budesonida Novolizer",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Formoterol Novolizer",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Salbutamol Novolizer",InhalerDetectionActivity.InhalerType.Novoziler);

            listMedicineNameRecognitionCodeToTake.put("Formatris-Novolizer",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Novopulm-Novolizer",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Brimica-Genuair",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Duaklir-Genuair",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Bretaris-Genuair ",InhalerDetectionActivity.InhalerType.Novoziler);
            listMedicineNameRecognitionCodeToTake.put("Eklira-Genuair",InhalerDetectionActivity.InhalerType.Novoziler);

            //Spiromax
            listMedicineNameRecognitionCodeToTake.put("DuoResp Spiromax",InhalerDetectionActivity.InhalerType.Spiromax);
            listMedicineNameRecognitionCodeToTake.put("BiResp Spiromax",InhalerDetectionActivity.InhalerType.Spiromax);

            listMedicineNameRecognitionCodeToTake.put("Aerivio-Spiromax",InhalerDetectionActivity.InhalerType.Spiromax);

            //Turbohaler
            listMedicineNameRecognitionCodeToTake.put("Assieme Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Bricanyl Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Oxis Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Pulmicort Nasal Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Pulmicort Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Symbicort Turbohaler",InhalerDetectionActivity.InhalerType.Turbohaler);

            listMedicineNameRecognitionCodeToTake.put("Rilast-Turbuhaler",InhalerDetectionActivity.InhalerType.Turbohaler);
            listMedicineNameRecognitionCodeToTake.put("Terbasmín-Turbuhaler",InhalerDetectionActivity.InhalerType.Turbohaler);

            listMedicineNameRecognitionCodeToTake.put("Budesonida Easyhaler",InhalerDetectionActivity.InhalerType.Easyhaler);
            listMedicineNameRecognitionCodeToTake.put("Bufomix-Easyhaler",InhalerDetectionActivity.InhalerType.Easyhaler);

            listMedicineNameRecognitionCodeToTake.put("Asmanex Twisthaler",InhalerDetectionActivity.InhalerType.Twisthaler);

            listMedicineNameRecognitionCodeToTake.put("Flutiform K-haller",InhalerDetectionActivity.InhalerType.KHaller);

            listMedicineNameRecognitionCodeToTake.put("Seretide Inalador ",InhalerDetectionActivity.InhalerType.Seretide);
            listMedicineNameRecognitionCodeToTake.put("Seretaide Inalador ",InhalerDetectionActivity.InhalerType.Seretide);

            listMedicineNameRecognitionCodeToTake.put("Foster-nexthaler",InhalerDetectionActivity.InhalerType.NextHaler);
            listMedicineNameRecognitionCodeToTake.put("Formodual nexthaler",InhalerDetectionActivity.InhalerType.NextHaler);
        }

        return listMedicineNameRecognitionCodeToTake;
    }

    public static String[] getMedicinesNeedInlNames(){
        if(medicinesNeedInlNames == null){
            HashMap<String,InhalerDetectionActivity.InhalerType> medicinesNeedInlNamesAux = getListMedicineNameRecognitionCodeToTake();

            medicinesNeedInlNames = new String[medicinesNeedInlNamesAux.keySet().size()];

            int auxInt = 0;
            for(String key : medicinesNeedInlNamesAux.keySet()){
                medicinesNeedInlNames[auxInt] = key;

                auxInt++;
            }
        }

        return medicinesNeedInlNames;
    }

    public static ArrayList<MedicineType> getMedicineTypes(Context context){
        if(listMediceTypes==null){
            listMediceTypes = new ArrayList<>();

            listMediceTypes.add(new MedicineType(MedicineTypeAux.TYPE1_CODE, context.getString(R.string.medicine_type_1)));
            listMediceTypes.add(new MedicineType(MedicineTypeAux.TYPE2_CODE, context.getString(R.string.medicine_type_2)));
            listMediceTypes.add(new MedicineType(MedicineTypeAux.TYPE3_CODE, context.getString(R.string.medicine_type_3)));
        }

        return listMediceTypes;
    }

    public static CharSequence[] getMedicineTypesNames(Context context){
        ArrayList<MedicineType> aux = getMedicineTypes(context);

        CharSequence[] result = new CharSequence[aux.size()];

        int pos = 0;

        for(MedicineType medicineType : aux){
            result[pos] = medicineType.getName();
            pos++;
        }

        return result;
    }

    public static MedicineType getMedicineType(String code,Context context){
        MedicineType aux = null;

        for(MedicineType m : getMedicineTypes(context)){
            if(m.getCode().equalsIgnoreCase(code)){
                aux = m;
                break;
            }
        }

        return aux;
    }

    public static int getMedicineTypeIcon(String code){
        return code.equals(TYPE1_CODE)? R.drawable.timeline_logo_inl:(code.equals(TYPE2_CODE)?R.drawable.timeline_logo_pils:R.drawable.timeline_logo_inl_nar);
    }

    public static int getTextResourceForTotal(String code) {
        return code.equals(TYPE1_CODE)? R.plurals.medicine_type_inal:(code.equals(TYPE2_CODE)?R.plurals.medicine_type_pil:R.plurals.medicine_type_inal_nar);
    }

    public static boolean needsDosesAndBarcode(String medicineName, MedicineType auxMedicineType) {
        return !medicineName.isEmpty() && checkMedicineName(medicineName) && auxMedicineType!=null && auxMedicineType.getCode().equals(TYPE1_CODE);
    }

    public static boolean needsOpenRecognitionToTake(String medicineName, MedicineType auxMedicineType) {
        return !medicineName.isEmpty() && /* checkMedicineName(medicineName) && */auxMedicineType!=null && (auxMedicineType.getCode().equals(TYPE1_CODE) || auxMedicineType.getCode().equals(TYPE2_CODE) || auxMedicineType.getCode().equals(TYPE3_CODE));
    }

    public static InhalerDetectionActivity.InhalerType getRecognitionCodeToTake(String medicineName) {
        InhalerDetectionActivity.InhalerType aux = getListMedicineNameRecognitionCodeToTake().get(medicineName);
        return aux!=null?aux:InhalerDetectionActivity.InhalerType.Unknown;//InhalerDetectionActivity.InhalerType.Flutiform;//!medicineName.isEmpty() && checkMedicineName(medicineName) && auxMedicineType!=null && auxMedicineType.getCode().equals(TYPE1_CODE);
    }

    private static boolean checkMedicineName(String medicineName) {
        boolean contains = false;

        String[] medicineNames = getMedicinesNeedInlNames();
        for(int i=0;i<medicineNames.length;i++){
            contains = medicineNames[i].equalsIgnoreCase(medicineName);

            if(contains){
                break;
            }
        }

        return contains;
    }
}
