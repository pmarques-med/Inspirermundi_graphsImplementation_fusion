package com.bloomidea.inspirers.swipeLayout.util;


public class Attributes {

    public enum Mode {
        Single, Multiple
    }
}
