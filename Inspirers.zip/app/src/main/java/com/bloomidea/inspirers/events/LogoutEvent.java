package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 21/04/17.
 */

public class LogoutEvent {
}
