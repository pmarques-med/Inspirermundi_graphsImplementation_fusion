package com.bloomidea.inspirers;

import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bloomidea.inspirers.model.MedicineInhaler;
import com.bloomidea.inspirers.model.MedicineType;
import com.bloomidea.inspirers.model.UserMedicine;
import com.bloomidea.inspirers.utils.MedicineTypeAux;
import com.bloomidea.inspirers.utils.Utils;

import static com.bloomidea.inspirers.utils.MedicineTypeAux.needsDosesAndBarcode;


public class AddMedicineStep1 extends Fragment {
    private static final String ARG_IS_SOS = "ARG_IS_SOS";
    private static final String ARG_MEDICINE_TO_EDIT = "ARG_MEDICINE_TO_EDIT";

    private boolean isSOS;

    private OnFragmentInteractionListener mListener;
    private View rootView;

    private UserMedicine medicineToEdit = null;

    public AddMedicineStep1() {
        // Required empty public constructor
    }

    public static AddMedicineStep1 newInstance(boolean isSOS, UserMedicine medicineToEdit) {
        AddMedicineStep1 fragment = new AddMedicineStep1();

        Bundle args = new Bundle();

        args.putBoolean(ARG_IS_SOS, isSOS);
        args.putSerializable(ARG_MEDICINE_TO_EDIT,medicineToEdit);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            isSOS = getArguments().getBoolean(ARG_IS_SOS);
            medicineToEdit = (UserMedicine) getArguments().getSerializable(ARG_MEDICINE_TO_EDIT);
        }
    }

    private int selectedTypePos;
    private View flutiformDosageBoxLayout;
    private EditText flutiformDosageEditText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(rootView==null) {
            rootView = inflater.inflate(R.layout.fragment_add_medicine_step1, container, false);

            if(isSOS){
                ((ImageView) rootView.findViewById(R.id.imageView8)).setImageResource(R.drawable.add_med_sos_first);
            }

            selectedTypePos = -1;
            flutiformDosageBoxLayout = rootView.findViewById(R.id.medicine_dosage_box);
            flutiformDosageEditText = (EditText) rootView.findViewById(R.id.medicine_dosage_editText);

            rootView.findViewById(R.id.medicine_type_box).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder adb = new AlertDialog.Builder(getActivity());

                    adb.setTitle(R.string.medicine_type_title);
                    adb.setSingleChoiceItems(MedicineTypeAux.getMedicineTypesNames(getActivity()), selectedTypePos, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            setSelectedMedicineTypeName(i);
                            dialogInterface.dismiss();
                        }
                    });

                    adb.setNegativeButton(getString(R.string.cancel), null);

                    adb.show();
                }
            });

            rootView.findViewById(R.id.proceed_btn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MedicineType auxMedicineType = selectedTypePos != -1 ? MedicineTypeAux.getMedicineTypes(getActivity()).get(selectedTypePos) : null;
                    String medicineName = ((EditText) rootView.findViewById(R.id.medicine_name_editText)).getText().toString();

                    String dosage = flutiformDosageEditText.getText().toString();
                    String barCode = ((EditText) rootView.findViewById(R.id.medicine_codebar)).getText().toString();

                    if (checkInfo(auxMedicineType, medicineName, dosage, barCode)) {
                        int dosageInt = 0;

                        try {
                            dosageInt = Integer.parseInt(dosage);
                        } catch (NumberFormatException e) {
                            Log.d("Exception", e.toString());
                        }

                        mListener.step1End(auxMedicineType, medicineName, dosageInt, barCode);
                    }
                }
            });


            if(medicineToEdit != null){
                loadMedicineInfo();
            }
        }

        return rootView;
    }

    private void loadMedicineInfo(){
        selectedTypePos = -1;
        CharSequence[] medicineTypesNames = MedicineTypeAux.getMedicineTypesNames(getActivity());

        for(int i=0 ; i< medicineTypesNames.length; i++){
            if(medicineTypesNames[i].toString().equals(medicineToEdit.getMedicineType().getName())){
                selectedTypePos = i;
                break;
            }
        }

        ((EditText) rootView.findViewById(R.id.medicine_name_editText)).setText(medicineToEdit.getMedicineName());



        if(medicineToEdit.getInhalers()!=null && !medicineToEdit.getInhalers().isEmpty()){
            MedicineInhaler inhaler = medicineToEdit.getInhalers().get(0);

            rootView.findViewById(R.id.medicine_dosage_box).setVisibility(View.VISIBLE);
            rootView.findViewById(R.id.medicine_codebar_box).setVisibility(View.VISIBLE);

            ((EditText) rootView.findViewById(R.id.medicine_dosage_editText)).setText(""+inhaler.getDosage());
            ((EditText) rootView.findViewById(R.id.medicine_codebar)).setText(inhaler.getBarcode());
        }

        setSelectedMedicineTypeName(selectedTypePos);
    }

    private boolean checkInfo(MedicineType auxMedicineType, String medicineName, String dosage, String barCode) {
        boolean ok = false;

        if(auxMedicineType==null){
            Toast.makeText(getActivity(),R.string.medicine_empty_error,Toast.LENGTH_SHORT).show();
        }else if(medicineName == null || medicineName.isEmpty()){
            Toast.makeText(getActivity(),R.string.medicine_empty_error,Toast.LENGTH_SHORT).show();
        }else {
            if(MedicineTypeAux.needsDosesAndBarcode(medicineName,auxMedicineType)){
                if(dosage==null || dosage.isEmpty()){
                    Toast.makeText(getActivity(),R.string.medicine_empty_error,Toast.LENGTH_SHORT).show();
                }/*else if(barCode==null && barCode.isEmpty()){
                    Toast.makeText(getActivity(),R.string.medicine_empty_error,Toast.LENGTH_SHORT).show();
                }*/else{
                    ok=true;
                }
            }else{
                ok = true;
            }
        }

        return ok;
    }

    private void setSelectedMedicineTypeName(int posSelected){
        selectedTypePos = posSelected;
        MedicineType aux = MedicineTypeAux.getMedicineTypes(getActivity()).get(selectedTypePos);

        ((TextView) rootView.findViewById(R.id.medicine_type_textView)).setText(aux.getName());

        if(aux.getCode().equals(MedicineTypeAux.TYPE1_CODE)){
            AutoCompleteTextView autoT = (AutoCompleteTextView) rootView.findViewById(R.id.medicine_name_editText);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, MedicineTypeAux.getMedicinesNeedInlNames());
            autoT.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    verifyMedicineInl();
                }
            });

            autoT.setAdapter(adapter);

            autoT.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean b) {
                    if (!b) {
                        verifyMedicineInl();
                    }
                }
            });
        }else{
            AutoCompleteTextView autoT = (AutoCompleteTextView) rootView.findViewById(R.id.medicine_name_editText);
            autoT.setAdapter(null);
        }

        verifyMedicineInl();
    }

    private void verifyMedicineInl(){
        MedicineType auxMedicineType = selectedTypePos!=-1?MedicineTypeAux.getMedicineTypes(getActivity()).get(selectedTypePos):null;

        String medicineName = ((EditText) rootView.findViewById(R.id.medicine_name_editText)).getText().toString();

        if(needsDosesAndBarcode(medicineName,auxMedicineType)){
            if(flutiformDosageBoxLayout.getVisibility()!=View.VISIBLE) {
                rootView.findViewById(R.id.medicine_dosage_box).setVisibility(View.VISIBLE);
                rootView.findViewById(R.id.medicine_codebar_box).setVisibility(View.VISIBLE);

                int pos[] = new int[2];

                rootView.findViewById(R.id.medicine_name_editText).getLocationOnScreen(pos);

                Utils.showFlutiformDialog(getActivity(), getActivity().getFragmentManager(), flutiformDosageEditText.getWidth(), pos[1], new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        flutiformDosageEditText.requestFocus();
                    }
                });
            }else{
                flutiformDosageEditText.requestFocus();
            }
        }else{
            rootView.findViewById(R.id.medicine_dosage_box).setVisibility(View.GONE);
            rootView.findViewById(R.id.medicine_codebar_box).setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) activity;
        } else {
            throw new RuntimeException(activity.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void step1End(MedicineType medicineType, String medicineName, int dosage, String barCode);
    }
}
