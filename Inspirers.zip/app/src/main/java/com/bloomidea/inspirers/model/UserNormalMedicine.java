package com.bloomidea.inspirers.model;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/**
 * Created by michellobato on 23/03/17.
 */

public class UserNormalMedicine extends UserMedicine {
    private int duration;
    private ArrayList<MedicineTime> times;

    public UserNormalMedicine(Long id, MedicineType medicineType, String medicineName, boolean shareWithDoctor, GregorianCalendar startDate, String note, ArrayList<MedicineInhaler> inhalers, int duration, ArrayList<MedicineTime> times, String nid) {
        super(id, medicineType, medicineName, shareWithDoctor, startDate, note, inhalers,nid);
        this.duration = duration;
        this.times = times;
    }

    public UserNormalMedicine(MedicineType medicineType, String medicineName, boolean shareWithDoctor, GregorianCalendar startDate, String note, ArrayList<MedicineInhaler> inhalers, int duration, ArrayList<MedicineTime> times, String nid) {
        super(medicineType, medicineName, shareWithDoctor, startDate, note, inhalers,nid);
        this.duration = duration;
        this.times = times;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public ArrayList<MedicineTime> getTimes() {
        return times;
    }

    public void setTimes(ArrayList<MedicineTime> times) {
        this.times = times;
    }
}
