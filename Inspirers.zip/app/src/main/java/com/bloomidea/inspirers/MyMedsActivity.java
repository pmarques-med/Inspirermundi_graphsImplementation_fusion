package com.bloomidea.inspirers;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bloomidea.inspirers.adapter.MyMedsAdapter;
import com.bloomidea.inspirers.application.AppController;
import com.bloomidea.inspirers.customViews.DividerItemDecoration;
import com.bloomidea.inspirers.events.MedicinesChangedEvent;
import com.bloomidea.inspirers.model.UserMedicine;
import com.bloomidea.inspirers.model.UserNormalMedicine;
import com.bloomidea.inspirers.utils.Utils;

import java.util.ArrayList;

public class MyMedsActivity extends AppCompatActivity {
    private RecyclerView medsRecyclerView;
    private MyMedsAdapter adapter;

    private ArrayList<UserMedicine> myMeds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_meds);

        configTopMenu();

        medsRecyclerView = (RecyclerView) findViewById(R.id.meds_recyclerView);

        loadMyMedsList();

        adapter = new MyMedsAdapter(this, myMeds, new MyMedsAdapter.MyMedsAdapterListener() {
            @Override
            public void medicineDelete(final UserMedicine medicineToDelete) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                //Yes button clicked
                                deleteMedicine(medicineToDelete);
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                dialog.cancel();
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(MyMedsActivity.this);
                builder.setMessage(R.string.delete_medicine).setPositiveButton(R.string.yes, dialogClickListener)
                        .setNegativeButton(R.string.no, dialogClickListener).show();
            }

            @Override
            public void medicineEdit(UserMedicine medicineToEdit) {
                if(medicineToEdit instanceof UserNormalMedicine){
                    Intent i = new Intent(MyMedsActivity.this, AddMedicineActivity.class);
                    i.putExtra(AddMedicineActivity.EXTRA_MEDICINE_EDIT,medicineToEdit);

                    Utils.openIntent(MyMedsActivity.this, i, R.anim.slide_in_left, R.anim.slide_out_left);
                }
            }
        });

        medsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        Drawable dividerDrawable = ContextCompat.getDrawable(this, R.drawable.line_divider);
        medsRecyclerView.addItemDecoration(new DividerItemDecoration(dividerDrawable,0));

        medsRecyclerView.setAdapter(adapter);
    }

    private void loadMyMedsList() {
        myMeds = AppController.getmInstance().getMedicineDataSource().getUserMedicines(AppController.getmInstance().getActiveUser().getId());

        verifyInfo(myMeds.isEmpty());
    }

    private void verifyInfo(boolean empty) {
        if(empty){
            ((TextView) findViewById(R.id.no_info_textView)).setText(R.string.no_medicines);
            findViewById(R.id.no_info_layout).setVisibility(View.VISIBLE);
            medsRecyclerView.setVisibility(View.GONE);
        }else{
            findViewById(R.id.no_info_layout).setVisibility(View.GONE);
            medsRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void deleteMedicine(final UserMedicine medicineToDelete){
        findViewById(R.id.deleting_linearlayout).setVisibility(View.VISIBLE);

        new Thread(new Runnable() {
            public void run() {
                if(AppController.getmInstance().deleteMedicine(medicineToDelete)){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AppController.getmInstance().getMyBus().send(new MedicinesChangedEvent());

                            myMeds.remove(medicineToDelete);
                            adapter.notifyDataSetChanged();

                            findViewById(R.id.deleting_linearlayout).setVisibility(View.GONE);

                            verifyInfo(myMeds.isEmpty());
                        }
                    });

                    AppController.getmInstance().forceSyncManual();
                }else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            findViewById(R.id.deleting_linearlayout).setVisibility(View.GONE);
                            Toast.makeText(MyMedsActivity.this, R.string.error_delete_medicine, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void configTopMenu() {
        findViewById(R.id.back_btn_imageView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ((TextView) findViewById(R.id.title_textView)).setText(R.string.my_meds);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadMyMedsList();
        adapter.setNewMedsList(myMeds);
    }
}
