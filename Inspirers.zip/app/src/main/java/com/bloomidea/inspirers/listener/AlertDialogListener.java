package com.bloomidea.inspirers.listener;

/**
 * Created by michellobato on 27/02/17.
 */

public interface AlertDialogListener {
    void okClick();
}
