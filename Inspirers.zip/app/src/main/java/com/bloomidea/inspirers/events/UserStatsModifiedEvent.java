package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 30/03/17.
 */

public class UserStatsModifiedEvent {
}
