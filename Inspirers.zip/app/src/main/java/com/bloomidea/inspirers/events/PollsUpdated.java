package com.bloomidea.inspirers.events;

/**
 * Created by michellobato on 27/04/17.
 */

public class PollsUpdated {
}
