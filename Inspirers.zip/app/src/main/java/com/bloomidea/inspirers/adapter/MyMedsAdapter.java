package com.bloomidea.inspirers.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bloomidea.inspirers.R;
import com.bloomidea.inspirers.model.UserMedicine;
import com.bloomidea.inspirers.model.UserSOSMedicine;
import com.bloomidea.inspirers.utils.MedicineTypeAux;
import com.bloomidea.inspirers.utils.Utils;

import java.util.ArrayList;

/**
 * Created by michellobato on 26/10/2017.
 */

public class MyMedsAdapter extends RecyclerView.Adapter<MyMedsAdapter.ViewHolderMyMeds>{
    private Activity context;
    private ArrayList<UserMedicine> auxListMeds;
    private MyMedsAdapterListener listener;

    public MyMedsAdapter(Activity context, ArrayList<UserMedicine> auxListMeds, MyMedsAdapterListener listener) {
        this.context = context;
        this.auxListMeds = auxListMeds;
        this.listener = listener;
    }

    @Override
    public MyMedsAdapter.ViewHolderMyMeds onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_my_medicine, parent, false);

        MyMedsAdapter.ViewHolderMyMeds viewHolder = new ViewHolderMyMeds(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyMedsAdapter.ViewHolderMyMeds holder, int position) {
        UserMedicine userMed = auxListMeds.get(position);

        holder.medicine_imageView.setImageResource(MedicineTypeAux.getMedicineTypeIcon(userMed.getMedicineType().getCode()));
        holder.medicine_text_textView.setText(userMed.getMedicineName());

        if(userMed instanceof UserSOSMedicine){
            holder.edit_medicine.setVisibility(View.GONE);
            Utils.changeBtnBackgroundMedicine(holder.medicine_imageView, R.drawable.item_medicine_sos_btn_back);
        }else{
            holder.edit_medicine.setVisibility(View.VISIBLE);
            Utils.changeBtnBackgroundMedicine(holder.medicine_imageView, R.drawable.item_medicine_normal_btn_back_green);
        }
    }

    @Override
    public int getItemCount() {
        return auxListMeds.size();
    }

    public void setNewMedsList(ArrayList<UserMedicine> newMedsList) {
        this.auxListMeds = newMedsList;
        notifyDataSetChanged();
    }

    public class ViewHolderMyMeds extends RecyclerView.ViewHolder {
        public ImageView medicine_imageView;
        public TextView medicine_text_textView;
        public View edit_medicine;
        public View delete_medicine;

        public ViewHolderMyMeds(View v) {
            super(v);

            medicine_imageView = (ImageView) v.findViewById(R.id.medicine_imageView);
            medicine_text_textView = (TextView) v.findViewById(R.id.medicine_text_textView);
            edit_medicine = v.findViewById(R.id.edit_medicine);
            delete_medicine = v.findViewById(R.id.delete_medicine);

            edit_medicine.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.medicineEdit(auxListMeds.get(getAdapterPosition()));
                }
            });


            delete_medicine.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.medicineDelete(auxListMeds.get(getAdapterPosition()));
                }
            });
        }
    }

    public interface MyMedsAdapterListener{
        void medicineDelete(UserMedicine medicineToDelete);
        void medicineEdit(UserMedicine medicineToEdit);
    }
}
